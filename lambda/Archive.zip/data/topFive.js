var topFive = [
    { number: "1", caption: "Visit the Hive Stadium and watch Barnet FC.", more: "Home to Barnet FC and arguably the leading state-of-the-art Centre for both football and fitness in the London area. The Hive, in Edgware, is a community facility offering both artificial and natural grass football pitches for hire at competitive rates. Facilities also include a Fitness Centre, meeting rooms, The Amber Lounge Bar and Restaurant, and 500-person banqueting and conferencing suite. ", location: "Camrose Avenue, Harrow HA8 6AG, England", contact: "020 8381 3800" }
];

module.exports = topFive;
